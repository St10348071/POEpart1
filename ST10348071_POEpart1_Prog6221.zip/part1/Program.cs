﻿using part1;

internal class Program
{
    private static void Main(string[] args)
    {
        try
        {
            Recipe recipes = new Recipe();

            // Prompting the user to enter information about the recipe

            Console.WriteLine("Enter the name of the recipe: ");
            recipes.Name = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("Enter the number of ingridients: ");
            int numOfIngridients = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the ingridients: ");

            for (int i = 0; i < numOfIngridients; i++)
            {
                Console.WriteLine($"Ingridient {i + 1}: ");
                string name = Console.ReadLine();

                Console.WriteLine("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Unit of measurement: ");
                string unit = Console.ReadLine();

                Ingridient ingridients = new Ingridient(name, quantity, unit);
                recipes.AddIngridient(ingridients);
            }

            Console.WriteLine();

            Console.WriteLine("Enter the number of steps: ");
            int numOfSteps = int.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("Enter the steps: ");

            for (int j = 0; j < numOfSteps; j++)
            {
                Console.WriteLine($"Step {j + 1}: ");
                string step = Console.ReadLine();
                recipes.AddStep(step);
            }

            Console.WriteLine();

            //Give the user options
            while (true)
            {
                Console.WriteLine("Options");
                Console.WriteLine("1. Display full recipe");
                Console.WriteLine("Scale the recipe");
                Console.WriteLine("Reset qualities to original values");
                Console.WriteLine("Clear all data and enter a new recipe");
                Console.WriteLine("5. Exit");
                Console.Write("Enter option: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        recipes.DisplayRecipe();
                        break;
                    case 2:
                        Console.WriteLine("Enter scaling factor (0.5, 2, 3): ");
                        double factor = double.Parse(Console.ReadLine());
                        recipes.ScaleRecipe(factor); 
                        break;
                    case 3:
                        recipes.ResetQuantities();
                        break;
                    case 4:
                        recipes.ClearData();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid clice selected. Please try agin");
                        break;
                }
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine("An error occured: " + ex.Message);
        }
        
    }
}