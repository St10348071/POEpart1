﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Ingridient
    {
        private string name;
        private double quantity;
        private double originalQuantity;
        private string unit;

        public string Name 
        { 
            get{ return name;} 
            set{ name = value;}
        }
        public double Quantity
        {
            get { return quantity;}
            set { quantity = value;} 
        }
        public double OriginalQuantity
        {
            get { return originalQuantity; }
            set { originalQuantity = value; }
        }
        public string Unit
        {
            get { return unit; }
            set { unit = value; }
        }

        public Ingridient(string name,  double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            OriginalQuantity = quantity;
            Unit = unit;
        }

        public void ResetQuantity()
        {
            Quantity = OriginalQuantity;
        }
    }
}
