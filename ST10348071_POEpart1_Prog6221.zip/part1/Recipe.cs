﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Recipe
    {
        private string name;
        private List<Ingridient> ingridients;
        private List<string> steps;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public List<Ingridient> Ingridients
        {
            get { return ingridients; }
            set { ingridients = value; }
        }
        public List<string> Steps
        {
            get { return steps; }
            set { steps = value; }
        }

        public Recipe()
        {
            Ingridients = new List<Ingridient>();
            Steps = new List<string>();
        }

        public void AddIngridient(string ingridient, string name, double quantity, string unit)
        {
            Ingridient ingridient1 = new Ingridient(name, quantity, unit);
            Ingridients.Add(ingridient1);
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe details: ");

            Console.WriteLine("Recipe name: " + Name);
            Console.Write("Ingridients:  ");

            foreach (var ingridient in Ingridients)
            {
                Console.WriteLine($"-{ingridient.Name} {ingridient.Quantity}, {ingridient.Unit}");
            }

            Console.WriteLine("Steps: ");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i+1}. {Steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingridient in Ingridients)
            {
                ingridient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            foreach (var ingridient in Ingridients)
            {
                ingridient.ResetQuantity();
            }
        }

        public void ClearData()
        {
            Name = string.Empty;
            Ingridients.Clear();
            Steps.Clear();
        }

        public void AddIngridient(Ingridient ingridients)
        {
            throw new NotImplementedException();
        }
    }
}
